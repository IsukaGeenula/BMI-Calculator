import 'package:flutter/material.dart';
import 'result_screen.dart';

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final _heightController = TextEditingController();
  final _weightController = TextEditingController();
  final _ageController = TextEditingController();

  double _bmi = 0.0;
  String _category = "";
  bool _isMale = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'BMI CALCULATOR',
          style: TextStyle(
            fontFamily: 'Pacifico',
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        decoration: BoxDecoration(
          color: Color(0xFFFDD6),
        ),
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Gender selection buttons with male and female symbols
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    OutlinedButton(
                      onPressed: () => setState(() => _isMale = true),
                      child: Text('♂️ Male'),
                      style: OutlinedButton.styleFrom(
                        primary: _isMale ? Colors.blue : Colors.black,
                      ),
                    ),
                    SizedBox(width: 10.0),
                    OutlinedButton(
                      onPressed: () => setState(() => _isMale = false),
                      child: Text('♀️ Female'),
                      style: OutlinedButton.styleFrom(
                        primary: !_isMale ? Colors.blue : Colors.black,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20.0),

                // Age input field
                TextField(
                  controller: _ageController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: 'Age',
                    fillColor: Color(0xFFE6E6FA),
                    filled: true,
                  ),
                ),
                SizedBox(height: 20.0),

                // Height and weight input fields in the same row with custom colors
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: Color(0xFFE6E6FA),
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        child: TextField(
                          controller: _heightController,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            labelText: 'Height (cm)',
                            labelStyle: TextStyle(color: Colors.black),
                            fillColor: Color(0xFFE6E6FA),
                            filled: true,
                          ),
                          style: TextStyle(color: Colors.black),
                        ),
                      ),
                    ),
                    SizedBox(width: 20.0),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: Color(0xFFE6E6FA),
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        child: TextField(
                          controller: _weightController,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            labelText: 'Weight (kg)',
                            labelStyle: TextStyle(color: Colors.black),
                            fillColor: Color(0xFFE6E6FA),
                            filled: true,
                          ),
                          style: TextStyle(color: Colors.black),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 20.0),

                // Calculate BMI button
                ElevatedButton(
                  onPressed: () {
                    final height = double.parse(_heightController.text);
                    final weight = double.parse(_weightController.text);
                    final age = int.parse(_ageController.text);

                    _bmi = weight / ((height / 100) * (height / 100));

                    if (_isMale) {
                      if (_bmi < 16) {
                        _category = 'Severe undernourishment';
                      } else if (_bmi >= 16 && _bmi <= 16.9) {
                        _category = 'Medium undernourishment';
                      } else if (_bmi >= 17 && _bmi <= 18.4) {
                        _category = 'Slight undernourishment';
                      } else if (_bmi >= 18.5 && _bmi <= 24.9) {
                        _category = 'Normal nutrition state';
                      } else if (_bmi >= 25 && _bmi <= 29.9) {
                        _category = 'Overweight';
                      } else if (_bmi >= 30 && _bmi <= 39.9) {
                        _category = 'Obesity';
                      } else {
                        _category = 'Pathological obesity';
                      }
                    } else {
                      if (_bmi < 16) {
                        _category = 'Severe undernourishment';
                      } else if (_bmi >= 16 && _bmi <= 16.9) {
                        _category = 'Medium undernourishment';
                      } else if (_bmi >= 17 && _bmi <= 18.4) {
                        _category = 'Slight undernourishment';
                      } else if (_bmi >= 18.5 && _bmi <= 24.9) {
                        _category = 'Normal nutrition state';
                      } else if (_bmi >= 25 && _bmi <= 29.9) {
                        _category = 'Overweight';
                      } else if (_bmi >= 30 && _bmi <= 39.9) {
                        _category = 'Obesity';
                      } else {
                        _category = 'Pathological obesity';
                      }
                    }

                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ResultScreen(
                          bmi: _bmi,
                          category: _category,
                        ),
                      ),
                    );
                  },
                  child: Text('Calculate BMI'),
                ),
                SizedBox(height: 20.0),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
