package com.example.flutter_application_bmi_cal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
